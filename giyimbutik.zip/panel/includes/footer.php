<footer>
    <div class="container">
        <p>&copy; 2023 GiyimButik. Tüm hakları saklıdır.</p>
    </div>
</footer>