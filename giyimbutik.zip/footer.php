<footer>
        <div class="container">
            <p>&copy; 2025 GiyimButik. Tüm hakları saklıdır.</p>
        </div>
    </footer>
    <script src="script.js"></script>
</body>
</html>